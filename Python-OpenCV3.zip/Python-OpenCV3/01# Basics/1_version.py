# -*- coding: utf-8 -*-
"""
Spyder Editor

This is a temporary script file.
"""

import cv2

def main():
    print(cv2.__version__)
    
if __name__ == "__main__":
    main()